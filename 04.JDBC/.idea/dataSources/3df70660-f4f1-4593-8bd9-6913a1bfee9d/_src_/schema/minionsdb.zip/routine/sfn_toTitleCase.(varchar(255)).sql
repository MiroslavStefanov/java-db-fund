CREATE FUNCTION sfn_toTitleCase(input VARCHAR(255))
  RETURNS VARCHAR(255)
  BEGIN   
	DECLARE i INT DEFAULT 1;
    DECLARE c CHAR(1);
    DECLARE bTitleCase BOOL DEFAULT TRUE;
    DECLARE bLowerCase BOOL DEFAULT FALSE;
    DECLARE sRet VARCHAR(255) DEFAULT '';
    WHILE i <= char_length(input) DO
		SET c = SUBSTRING(input, i, 1);
        IF c = ' ' THEN
			SET bTitleCase = TRUE;
            SET bLowerCase = FALSE;
            SET sRet = CONCAT(sRet, ' ');
		ELSEIF bLowerCase THEN
			SET c = LOWER(c);
		ELSEIF bTitleCase THEN
			SET c = UPPER(c);
            SET bTitleCase = FALSE;
            SET bLowerCase = TRUE;
		END IF;
        SET sRet = CONCAT(sRet, c);
        SET i = i+1;
    END WHILE;
    RETURN sRet;
END;
