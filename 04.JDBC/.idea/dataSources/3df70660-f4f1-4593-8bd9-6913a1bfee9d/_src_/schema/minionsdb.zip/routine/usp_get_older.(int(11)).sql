CREATE PROCEDURE usp_get_older(IN nId INT)
  BEGIN
	UPDATE minions
    SET age = age+1
    WHERE id = nId;
    
    commit;
END;
