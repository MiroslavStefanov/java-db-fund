package app.exam.controller;

import org.springframework.stereotype.Controller;

@Controller
public class EmployeesController {
    public String importDataFromJSON(String jsonContent){
        return null;
    }
}
