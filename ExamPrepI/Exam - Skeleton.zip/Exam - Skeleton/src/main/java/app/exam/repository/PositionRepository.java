package app.exam.repository;

public interface PositionRepository {;
}
